// KryoSS v4 compute (KryLabs) - gl/KryoSS/KryoSSCompute.h
// Caminho compute (GLES 3.1) do KryoSS: um dispatch de tiles 16x16 escreve direto na textura alvo (RGBA8, imagem),
// no lugar do draw do fullscreen quad. Tudo e opcional: se o driver nao tem compute/imagens, se a chave upscalerCompute = 0
// ou se o shader nao compilar/linkar, g_useCompute fica false e o FSR1.cpp segue com o fragment shader de sempre.
// Incluido SO por FSR1.cpp (usa GLES, LOG_*, global_settings e kryoss::MakeParams do contexto dele).
// Licenciado como o MobileGlues: LGPL-2.1-only.
#pragma once
#include <string>
#include "KryoSSComputeSource.h"

namespace kryoss_cs {

struct State {
    bool use = false;          // caminho compute ativo (decidido em Init; a textura alvo e alocada imutavel quando true)
    GLuint program = 0;
    GLint viewLoc = -1, outLoc = -1;
};
inline State g;

inline bool Supported() {
    return GLES.glDispatchCompute && GLES.glBindImageTexture && GLES.glMemoryBarrier && GLES.glTexStorage2D &&
           GLES.glCreateShader && GLES.glShaderSource && GLES.glCompileShader;
}

// Compila e linka o compute direto no driver ES (sem a traducao GLSL 450 -> ES do frontend: a fonte ja e "#version 310 es").
inline GLuint Build(int tier) {
    const std::string src = std::string("#version 310 es\n#define KRYOSS_MODE ") + std::to_string(tier) + "\n" + KRYOSS_CSBody;
    const char* p = src.c_str();
    GLuint cs = GLES.glCreateShader(GL_COMPUTE_SHADER);
    GLES.glShaderSource(cs, 1, &p, nullptr);
    GLES.glCompileShader(cs);
    GLint ok = 0;
    GLES.glGetShaderiv(cs, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024] = {0};
        GLES.glGetShaderInfoLog(cs, sizeof(log) - 1, nullptr, log);
        LOG_F("KryoSS compute shader error (usando o fragment shader): %s\n", log);
        GLES.glDeleteShader(cs);
        return 0;
    }
    GLuint prog = GLES.glCreateProgram();
    GLES.glAttachShader(prog, cs);
    GLES.glLinkProgram(prog);
    GLES.glDeleteShader(cs);
    GLES.glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024] = {0};
        GLES.glGetProgramInfoLog(prog, sizeof(log) - 1, nullptr, log);
        LOG_F("KryoSS compute link error (usando o fragment shader): %s\n", log);
        GLES.glDeleteProgram(prog);
        return 0;
    }
    return prog;
}

// Chamado em InitFSRResources (com o programa de fragment ja compilado). tier: 0..3.
inline void Init(int tier, int sharpPct, int detailPct) {
    g = State();
    if (global_settings.upscaler_mode != 1 || global_settings.upscaler_compute == 0 || !Supported()) return;
    g.program = Build(tier);
    if (!g.program) return;
    g.viewLoc = GLES.glGetUniformLocation(g.program, "uViewportSize");
    g.outLoc = GLES.glGetUniformLocation(g.program, "uOutSize");
    const GLint k1 = GLES.glGetUniformLocation(g.program, "uKryoss");
    const GLint k2 = GLES.glGetUniformLocation(g.program, "uKryoss2");
    const GLint tex = GLES.glGetUniformLocation(g.program, "uInputTex");
    const kryoss::Params kp = kryoss::MakeParams(tier, sharpPct, detailPct, /*compute=*/true);
    GLES.glUseProgram(g.program);
    GLES.glUniform1i(tex, 0);
    GLES.glUniform4fv(k1, 1, kp.u1);
    GLES.glUniform4fv(k2, 1, kp.u2);
    GLES.glUseProgram(0);
    g.use = true;
    LOG_D("KryoSS v4 COMPUTE: tier=%d taps=%d sharp=%d detail=%d", tier, kryoss::TapsFor(tier, true), sharpPct, detailPct);
}

// Aloca a textura alvo: sempre imutavel (obrigatorio para glBindImageTexture no compute; no caminho fragment so evita re-especificacao).
inline void AllocTarget(GLsizei w, GLsizei h) {
    if (GLES.glTexStorage2D) GLES.glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA8, w, h);
    else GLES.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);   // g.use implica glTexStorage2D (Supported())
}

// Substitui clear + draw do ApplyFSR. A textura de entrada (render) deve estar ligada na unidade 0.
// Ao fim, a unidade de imagem 0 e zerada (o app nao usa imagens; nao restauramos um binding anterior).
inline void Dispatch(GLuint targetTex, int inW, int inH, int outW, int outH) {
    GLES.glUseProgram(g.program);
    GLES.glUniform2f(g.viewLoc, (float)inW, (float)inH);
    GLES.glUniform2f(g.outLoc, (float)outW, (float)outH);
    GLES.glBindImageTexture(0, targetTex, 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA8);
    GLES.glDispatchCompute((GLuint)((outW + 15) / 16), (GLuint)((outH + 15) / 16), 1);
    // o blit seguinte le a textura alvo pelo framebuffer
    GLES.glMemoryBarrier(GL_FRAMEBUFFER_BARRIER_BIT | GL_TEXTURE_FETCH_BARRIER_BIT);
    GLES.glBindImageTexture(0, 0, 0, GL_FALSE, 0, GL_READ_ONLY, GL_RGBA8);
}

} // namespace kryoss_cs
