// KryoSS v4 (KryLabs) - gl/KryoSS/KryoSSParams.h
// Tabela de parametros por modo. C++ puro (sem GL): compila no host e e usada por FSR1.cpp e por tests/test_kryoss.py.
// Espelho em Kotlin: renderer/RendererProfile.kt (KryoSSMode) e em Python: tests/kryoss_ref.py (params()).
// Valores ajustados no host com tests/kryoss_bench.py (busca por coordenadas sobre cenas sinteticas + cena do demo); ver docs/KRYOSS.md.
// Constantes por modo que ficam no shader (nao uniformes): kryossLen() (expoente da coerencia) e kWidthK.
// Licenciado como o MobileGlues: LGPL-2.1-only.
#pragma once

namespace kryoss {

enum Tier : int { ULTRA_PERF = 0, PERFORMANCE = 1, BALANCED = 2, QUALITY = 3, TIER_COUNT = 4 };

// u1 -> uniforme uKryoss : (kmix, lob0, lob1, flatT)
// u2 -> uniforme uKryoss2: (boost, sobrepasso, dither, along)
struct Params {
    float u1[4];
    float u2[4];
};

inline float clamp01(float v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }

// tier: 0..3 (fora disso vira Balanceado); sharpPct e detailPct: 0..100.
// compute = true: kryoss_upsample.comp, cujo modo Qualidade usa 16 taps e uma linha propria de parametros.
inline Params MakeParams(int tier, int sharpPct, int detailPct, bool compute = false) {
    if (tier < 0 || tier >= TIER_COUNT) tier = BALANCED;
    const float s = clamp01(sharpPct / 100.0f);
    const float d = clamp01(detailPct / 100.0f);

    // kmix = base + slope*s : mistura bilinear -> reconstrucao (1.0 = reconstrucao pura; >1 extrapola, limitado pelo AABB).
    // lob0 = base - 0.12*d  : lobo negativo do nucleo em bordas fracas (detalhe maior = nucleo mais estreito).
    // lob1 : lobo em borda "perfeita".  flatT : contraste abaixo do qual so o bilinear e usado (custo x qualidade).
    // boost = nitidez extra em baixo contraste (x s). sobrepasso = expansao da caixa YCoCg de deringing (x s; 0 em todos: nao melhorou nas metricas).
    // along = quanto o nucleo alarga ao longo da borda (suaviza a escadinha do render sem filtro).
    static const float kBase[TIER_COUNT]  = {0.495f, 0.745f, 0.540f, 0.540f};
    static const float kSlope[TIER_COUNT] = {0.40f, 0.40f, 0.40f, 0.40f};
    static const float kLob0[TIER_COUNT]  = {0.480f, 0.209f, 0.268f, 0.268f};
    static const float kLob1[TIER_COUNT]  = {0.14f, 0.15f, 0.15f, 0.15f};
    static const float kBoost[TIER_COUNT] = {0.00f, 0.00f, 0.03f, 0.03f};
    static const float kOver[TIER_COUNT]  = {0.00f, 0.00f, 0.00f, 0.00f};
    static const float kFlat[TIER_COUNT]  = {0.05f, 0.04f, 0.03f, 0.02f};
    static const float kAlong[TIER_COUNT] = {0.42f, 0.25f, 0.33f, 0.33f};
    static const float kDith[TIER_COUNT]  = {0.0f, 0.0f, 0.0f, 1.0f / 255.0f};

    Params p;
    p.u1[0] = kBase[tier] + kSlope[tier] * s;       // kmix
    p.u1[1] = kLob0[tier] - 0.12f * d;              // lob0
    p.u1[2] = kLob1[tier];                          // lob1
    p.u1[3] = kFlat[tier];                          // flatT
    p.u2[0] = kBoost[tier] * s;                     // boost
    p.u2[1] = kOver[tier] * s;                      // sobrepasso
    p.u2[2] = kDith[tier];                          // dither (amplitude)
    p.u2[3] = kAlong[tier];                         // along
    if (compute && tier == QUALITY) {               // espelho de COMPUTE_Q em tests/kryoss_ref.py
        p.u1[0] = 0.70f + kSlope[tier] * s;
        p.u1[1] = 0.285f - 0.12f * d;
        p.u1[2] = 0.18f;
        p.u2[3] = 0.45f;
    }
    return p;
}

// Quantos fetches de textura o modo faz fora da regiao plana (so informativo / documentacao).
inline int TapsFor(int tier, bool compute = false) {
    static const int t[TIER_COUNT] = {4, 8, 12, 12};
    if (compute && tier == QUALITY) return 16;
    return (tier >= 0 && tier < TIER_COUNT) ? t[tier] : 12;
}

} // namespace kryoss
