// KryoSS - gl/KryoSS/KryoSSResolution.h
// Conta pura (sem GL) da "Resolucao minima base": tamanho interno de render e conversao de coordenadas da janela para o FBO menor.
// Usada por gl/FSR1/FSR1.cpp e gl/framebuffer.cpp, e testada no host por tests/kryoss_resolution_check.cpp.
#pragma once

namespace kryoss {

// Resolucao em que o jogo desenha: altura = base (px), largura pela proporcao da janela, ambas pares, nunca acima da janela.
// base <= 0 ou base >= altura da janela = sem reducao (render = janela).
inline void RenderSize(int surfW, int surfH, int base, int* rw, int* rh) {
    *rw = surfW;
    *rh = surfH;
    if (base <= 0 || surfW <= 0 || surfH <= 0 || base >= surfH) return;
    long long h = base;
    long long w = static_cast<long long>(surfW) * h / surfH;
    w = (w + 1) & ~1LL;
    h = (h + 1) & ~1LL;
    if (w > surfW) w = surfW;
    if (h > surfH) h = surfH;
    if (w < 2) w = 2;
    if (h < 2) h = 2;
    *rw = static_cast<int>(w);
    *rh = static_cast<int>(h);
}

// v (pixels da janela) -> pixels do render, com arredondamento ao mais proximo. from = tamanho da janela, to = tamanho do render.
inline int ScaleCoord(int v, int from, int to) {
    if (from <= 0) return v;
    return static_cast<int>((static_cast<long long>(v) * to + from / 2) / from);
}

// Retangulo x,y,w,h da janela -> render. Um w/h positivo nunca vira 0 (um scissor de 1 px continua existindo).
inline void ScaleRect(int* x, int* y, int* w, int* h, int surfW, int surfH, int rw, int rh) {
    *x = ScaleCoord(*x, surfW, rw);
    *y = ScaleCoord(*y, surfH, rh);
    if (*w > 0) { *w = ScaleCoord(*w, surfW, rw); if (*w < 1) *w = 1; }
    if (*h > 0) { *h = ScaleCoord(*h, surfH, rh); if (*h < 1) *h = 1; }
}

} // namespace kryoss
