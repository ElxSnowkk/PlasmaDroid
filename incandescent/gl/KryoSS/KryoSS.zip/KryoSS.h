// KryoSS spatial upscaler — independent IncandescentGlues module.
// SPDX-License-Identifier: LGPL-2.1-only
#pragma once

#include "../../gles/gles.h"

namespace KryoSS {
// GLSL source selected from the configured quality tier. The tier is fixed for
// the lifetime of the program, so this is intentionally built once per process.
const char* FragmentSource();
// Compute path is available on ES 3.1+ and writes to an RGBA8 image.
const char* ComputeSource();

// Called with the corresponding program current. Static params are uploaded once.
void BindProgramUniforms(GLuint program);
void BindComputeUniforms(GLuint program);
} // namespace KryoSS
